package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.RatingDao;
import com.virtusa.riotshoppyapp.dto.Rating;

@Repository
@Transactional
public class RatingDaoImpl implements RatingDao
{
	@Autowired
	private SessionFactory sessionFactory;	
	
	@Override
	public int saveProductRating(Rating rating)
	{
		
			return (int)this.sessionFactory.getCurrentSession().save(rating);
	}	
		
	@Override
	public List<Rating> getProductratings(int productId)
	{
		String hql = "From Rating where productId = :productId";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		q.setParameter("productId", productId);
		return q.list();
	}


	@Override
	public Rating getRatingInfo(int ratingId) {
		// TODO Auto-generated method stub
		return null;
	}

}
