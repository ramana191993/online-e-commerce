package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.FeedbackDao;
import com.virtusa.riotshoppyapp.dto.UserFeedback;

@Repository
@Transactional
public class FeedbackDaoImpl implements FeedbackDao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int saveUserFeedback(UserFeedback feedback)
	{
		return (int) this.sessionFactory.getCurrentSession().save(feedback);
	}

	@Override
	public List<UserFeedback> viewAllFeedbacks() 
	{
		String hql = "FROM UserFeedback";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		
		return q.list();
	}

}
