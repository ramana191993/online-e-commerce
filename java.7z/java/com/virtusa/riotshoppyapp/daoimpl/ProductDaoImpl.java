package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.ProductDao;
import com.virtusa.riotshoppyapp.dto.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao
{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int addProduct(Product product)
	{
		return (int) this.sessionFactory.getCurrentSession().save(product);
	}

	@Override
	public List<Product> viewAllProducts()
	{
		String hql = "FROM Product ";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		List<Product> list = query.list();
		
		return list;
	}

	@Override
	public List<Product> getProductsByPrice(double lowPrice, double maxPrice) 
	{
		String hql = "FROM Product WHERE productPrice BETWEEN :lowPrice AND :maxPrice";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("lowPrice", lowPrice);
		query.setParameter("maxPrice", maxPrice);
		List<Product> list = query.list();
		
		return list;
	}
	
	@Transactional
	@Override
	public Product getProduct(int productId) 
	{
		Product product = this.sessionFactory.getCurrentSession().get(Product.class, productId);
		return product;
	}

	@Override
	public void removeProduct(int productId) {
		this.sessionFactory.getCurrentSession().delete(this.getProduct(productId));
	}
	
	@Override
	public List<Product> viewProductsByCategory(int categoryId)
	{
		String hql = "FROM Product WHERE catId = :catId";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("catId", categoryId);
		List<Product> list = query.list();
		
		return list;
	}

	@Override
	public List<Product> getProductBasBrand(int brandId) 
	{	
		String hql = "FROM Product where brandId = :brandId";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("brandId", brandId);
		return query.list();
	}

	@Override
	public int updateProduct(Product product) {
		// TODO Auto-generated method stub
		return 0;
	}

}
