package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.CartDao;
import com.virtusa.riotshoppyapp.dao.ProductDao;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Product;

@Repository
@Transactional
public class CartDaoImpl implements CartDao
{
	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired 
	ProductDaoImpl productDao;
	
	@Override
	public int addProductToCart(Cart cart)
	{
		Session session = sessionFactory.getCurrentSession();
		int i = 0;
		String hql = "from Cart where productId = :productId and userName = :usr";
		Query q = session.createQuery(hql);
		q.setParameter("productId", cart.getProductId());
		q.setParameter("usr", cart.getUserName());
		List list = q.list();
		
		if(!list.isEmpty())
		{			
			for(Object obj : list)
			{
				Cart crt = (Cart)obj;
				String update = "update Cart set prodQty = :prodQty ,prodPrice = :prodPrice where cartId = :cartId";
				Query up = session.createQuery(update);
				up.setParameter("prodQty", crt.getProdQty()+1);
				up.setParameter("prodPrice", crt.getProdPrice()+cart.getProdPrice());
				up.setParameter("cartId", crt.getCartId());
				
				i = up.executeUpdate();
			}
		}
		else 
		{
			i =(int) session.save(cart);
		}
		return i;
	}
	

	@Override
	public List<Cart> viewCartItems(String userName) 
	{
		String hql = "FROM Cart WHERE userName = :userName";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("userName", userName);
		List<Cart> list = query.list();
		
		return list;
	}
	
	@Override
	public void removeProductFromCart(Cart cart)
	{
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "from Cart where productId = :productId and userName = :userName";
		Query query = session.createQuery(hql);
		query.setParameter("productId", cart.getProductId());
		query.setParameter("userName", cart.getUserName());
		
		List list = query.list();
		for(Object obj : list)
		{
			Cart c = (Cart) obj;
			System.out.println(c.getProdQty());
			if( c.getProdQty() > 1) {
				int ct =  c.getProdQty()-1;
				Product p = productDao.getProduct(cart.getProductId());
				double price = c.getProdPrice() - p.getProductPrice();
				System.out.println(ct + "  " +price);
				
				String hq = "update Cart set prodQty = :qty, prodPrice = :pr where productId = :productId and userName = :userName";
				Query q1 = session.createQuery(hq);
				q1.setParameter("qty", ct);
				q1.setParameter("pr",price );
				q1.setParameter("productId", cart.getProductId());
				q1.setParameter("userName", cart.getUserName());
				q1.executeUpdate();
			}else {
				session.delete(c);
			}			
		}
	}
	
	@Transactional
	@Override
	public int increaseProductQty(Cart cart)
	{
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "from Cart where productId = :productId and userName = :userName";
		Query q = session.createQuery(hql);
		q.setParameter("productId", cart.getProductId());
		q.setParameter("userName", cart.getUserName());
		List list = q.list();
		for(Object obj : list)
		{
			Cart c = (Cart) obj;
			
			int ct =  c.getProdQty()+1;
			Product p = productDao.getProduct(cart.getProductId());
			double price = c.getProdPrice() + p.getProductPrice();
			System.out.println(ct + "  " +price);
			
			String hq = "update Cart set prodQty = :qty, prodPrice = :pr where productId = :productId and userName = :userName";
			Query q1 = session.createQuery(hq);
			q1.setParameter("qty", ct);
			q1.setParameter("pr",price );
			q1.setParameter("productId", cart.getProductId());
			q1.setParameter("userName", cart.getUserName());
			return q1.executeUpdate();
		}

		return 0;
	}

}
