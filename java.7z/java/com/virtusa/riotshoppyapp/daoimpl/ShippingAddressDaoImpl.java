package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.ShippingAddressDao;
import com.virtusa.riotshoppyapp.dto.ShippingAddress;

@Repository
@Transactional
public class ShippingAddressDaoImpl implements ShippingAddressDao
{
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public int addShippingAddress(ShippingAddress address)
	{
		System.out.println(address);
		return (int)this.sessionFactory.getCurrentSession().save(address);
	}

	@Override
	public List<ShippingAddress> getAllShippingAddress(String userName) 
	{
		String hql = "from ShippingAddress where userName = :userName";
		System.out.println(userName);
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("userName", userName);
		
		return query.list();
	}

}
