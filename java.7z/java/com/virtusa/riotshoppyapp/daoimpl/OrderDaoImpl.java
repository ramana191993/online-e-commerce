package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;
import com.virtusa.riotshoppyapp.dao.OrderDao;
import com.virtusa.riotshoppyapp.dto.Orders;

@Repository
@Transactional
public class OrderDaoImpl implements OrderDao
{
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public int saveOrder(List<Orders> order) 
	{
		int a = 0;
		for(Orders ord : order)
			a = (int)this.sessionFactory.getCurrentSession().save(ord);
		return a;
	}

	@Override
	public List<Orders> viewOrder(int orderId)
	{
		String hql = "from Orders where  orderId = :id";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		q.setParameter("id", orderId);	 	
		return q.list();
	}
	
	@Override
	public List<Orders> viewAllOrders(String userName) 
	{
		String hql = "from Orders where userName = :un ";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		q.setParameter("un", userName);	
		return q.list();
	}

	@Override
	public void cancelOrder(int orderNo, int orderId) 
	{
		String hql = "from Orders where  orderId = :id and sNo = :orderNo";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		q.setParameter("id", orderId);	
		q.setParameter("orderNo", orderNo);	
		List<Orders> list = q.list();
		for(Orders o : list) {
			this.sessionFactory.getCurrentSession().delete(o);
		}	
	}

	@Override
	public List<Orders> viewAllOrders()
	{
		String hql = "from Orders";
		Query q = this.sessionFactory.getCurrentSession().createQuery(hql);
		return q.list();
	}

}
