package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.riotshoppyapp.dao.BrandDao;
import com.virtusa.riotshoppyapp.dto.Brands;

@Repository
@Transactional
public class BrandDaoImpl implements BrandDao
{
	@Autowired
	private SessionFactory sessionFactory;
	

	@Override
	public int addNewBrand(Brands brand) 
	{
		return (int) this.sessionFactory.getCurrentSession().save(brand);
	}

	@Override
	public List<Brands> getBrandsList(int categoryId) 
	{
		String hql = "FROM Brands where categoryId = :categoryId";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("categoryId", categoryId);
		return query.list();
	}

}
