package com.virtusa.riotshoppyapp.daoimpl;

import java.util.List;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.virtusa.riotshoppyapp.dao.UserDao;
import com.virtusa.riotshoppyapp.dto.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao
{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int register(User user) 
	{		
		User u = getUserInformation(user.getUserName());
		if(u != null)
			return 2;
		return (int)sessionFactory.getCurrentSession().save(user);
	}
	
	@Override
	public User getUserInformation(String userName) 
	{
		String hql = "FROM User WHERE userName = :userName";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("userName", userName);
		List<User> list = query.list();
		User userObj = null;
		
		for(User u : list)
			userObj = u;
		
		return userObj;
	}

	@Override
	public int updatePassword(User user)
	{
		String hql = "UPDATE User SET password = :password WHERE userName = :userName";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("password", user.getPassword());
		query.setParameter("userName", user.getUserName());
		int a = query.executeUpdate();
		return a;
	}

	@Override
	public List<User> viewAllUsers() 
	{
		String hql = "from User";
		Query query = this.sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

	@Override
	public void removeUser(String userName)
	{
		this.sessionFactory.getCurrentSession().delete(this.getUserInformation(userName));
	}

	@Override
	public int updateUserProfile(User user)
	{
		// TODO Auto-generated method stub
		return 0;
	}

}
