package com.virtusa.riotshoppyapp.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.javafx.sg.prism.NGShape.Mode;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.Rating;
import com.virtusa.riotshoppyapp.dto.ShippingAddress;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.servicesimpl.UserCartServicesImpl;
import com.virtusa.riotshoppyapp.servicesimpl.UserServicesImpl;

@Controller
public class UserCartController
{
	@Autowired
	UserCartServicesImpl userServices;
	
	@Autowired 
	UserServicesImpl serv;
	
	
	@PostMapping("removeprod")
	public String removeProductFromCart(@ModelAttribute Cart cart) 
	{		
		userServices.decreasePoductQty(cart);
		return "redirect:viewcart";
	}
	@PostMapping("inCartProd")
	public String increaseProductQty(@ModelAttribute Cart cart)
	{
		userServices.increaseProductQty(cart);
		return "redirect:viewcart";
	}
	
	@RequestMapping("/checkout")
	public String checkoutPage(HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{	
			User u = (User)session.getAttribute("user");
			List<ShippingAddress> address = userServices.getAllShippingAddresses(u.getUserName());
			System.out.println(address);
			session.setAttribute("shippingAddresses", address);
			return "checkout";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/addShippingAddress")
	public String getNewShippingAddressPage(@ModelAttribute ShippingAddress address, HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{	
			return "add_new_address";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@PostMapping("/addshippingadd")
	public String addNewShippingAddress(@ModelAttribute ShippingAddress address,Model m)
	{
		int a = userServices.addNewShipmentAddress(address);
		if( a > 0)
		{
			return "redirect:checkout";
		}else {
			m.addAttribute("msg", "OOP's Error Please try again :(");
			return "add_new_address";
		}
	}
	
	@RequestMapping("/payment")
	public String getPaymentPage(@RequestParam("address") String address, HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{	session.setAttribute("address", address);
			return "payment";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/card_payment")
	public String getCardPaymentPage(HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{	
			return "card_payment";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/saveorder")
	public String saveOrder(HttpSession session,Model m )
	{
		if(session.getAttribute("user") != null)
		{	
			String address = session.getAttribute("address").toString();
			List<Cart> cart = (List<Cart>)session.getAttribute("cart");
			int a = userServices.saveOrderInfo(address, cart);
			if(a > 0) {
				session.setAttribute("orderId", a);
				return "place_order";
			}
			else {
				m.addAttribute("message", "Error :(");
				return "payment";		
			}
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/viewOrder")
	public String viewOrder(HttpSession session,Model m)
	{
		if(session.getAttribute("user") != null)
		{	
			int orderId = Integer.parseInt(session.getAttribute("orderId").toString());
			List<Orders> viewOrder = userServices.viewOrder(orderId);
			m.addAttribute("order", viewOrder);
			return "view_order";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/viewOrders")
	public String getMyOrdersPage(HttpSession session, Model m)
	{
		if(session.getAttribute("user") != null)
		{	
			User u = (User)session.getAttribute("user");
			List<Orders> allOrder = userServices.getAllOrder(u.getUserName());
			m.addAttribute("myOrders", allOrder);	
			return "my_orders";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/cancelOrder")
	public String cancelOrder(@RequestParam("id") String id, HttpSession session) 
	{
		if(session.getAttribute("user") != null)
		{	
			userServices.cancelOrder(id);
			return "redirect:viewOrders";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/sortbybrabnd")
	public String filterProductByBrand(@RequestParam("id") int brandId, Model m, HttpSession session) 
	{
		if(session.getAttribute("user") != null)
		{	
			List<Product> produts = userServices.getProductsByBrand(brandId);
			if(!produts.isEmpty() && produts != null)
			{
				m.addAttribute("produts", produts);
				return "brand_wise_products";
			}
			return "product_not_found";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/productInfo")
	public String displayProductInfo(@RequestParam("id") int productId,HttpSession session, Model m)
	{	
		if(session.getAttribute("user") != null)
		{
			double finalRating = serv.getCaliculatedRating(productId);
			session.setAttribute("finalRating", finalRating);
			List<Rating> productRatings = serv.getProductRatings(productId);
			session.setAttribute("rating", productRatings);
			Product product = userServices.getProduct(productId);
				session.setAttribute("product", product);
			return "display_product";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
}
