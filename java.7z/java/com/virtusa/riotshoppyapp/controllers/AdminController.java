package com.virtusa.riotshoppyapp.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.mysql.cj.protocol.a.MultiPacketReader;
import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.dto.UserFeedback;
import com.virtusa.riotshoppyapp.servicesimpl.AdminServicesImpl;

@Controller
@RequestMapping("/admin")
public class AdminController
{
	@Autowired
	AdminServicesImpl adminServices;
	
	@Autowired
	FileUpload imgUpload;
		
	@RequestMapping("/login")
	public String getAdminLogin()
	{
		return "admin_login";
	}
	
	@RequestMapping("/adIndex")
	public String getAdminIndex(HttpSession session)
	{
		if(session.getAttribute("admin") != null)
		{
			return "admin_index";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@PostMapping("/lgvalid")
	public String validateAdminLogin(@RequestParam("userName") String userName, @RequestParam("password") String password ,Model m,HttpSession session)
	{
	
		if(adminServices.loginValidation(userName, password))
		{	
			session.setAttribute("admin","admin");
			return "admin_index";
		}else 
		{	
			m.addAttribute("msg", "Username and password are not match Try again");
			return "admin_login";
		}		
	}
	
	@RequestMapping("/addBrand")
	public String getAddBrandPage(HttpSession session) {
		if(session.getAttribute("admin") != null)
		{
			return "admin_add_brand";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@PostMapping("/addbrand")
	public String addBrand(@ModelAttribute Brands brand, Model m)
	{
		int b = adminServices.addNewBrand(brand);
		if(b > 0) {
			m.addAttribute("smsg", "Brand Saved Sucessfully :)");
			return "admin_add_brand";
		}else {
			m.addAttribute("emsg", "OOP'S Error Try again :(");
			return "admin_add_brand";
		}
	}
	
	@RequestMapping("/addprod")
	public String addProductPage(HttpSession session)
	{
		if(session.getAttribute("admin") != null)
		{
			return "admin_add_product";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@PostMapping("/getBrands")
	public String getBrands(@RequestParam("categoryId") int categoryId,HttpSession session, Model m)
	{
		if(session.getAttribute("admin") != null)
		{
			List<Brands> brandsList = adminServices.getBrandsList(categoryId);
			if(!brandsList.isEmpty() && brandsList != null) {
				m.addAttribute("brands", brandsList);
				return "admin_add_product1";
			}
			session.setAttribute("emsg", "No Brands Found Please Add Brand :(");
			return "redirect:addbrand";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@PostMapping("/saveProduct")
	public String addNewProduct(@RequestParam("catId") int catId,
								@RequestParam("brandId") int brandId,
								@RequestParam("productId") int productId,
								@RequestParam("productTitle") String productTitle,
								@RequestParam("productDesc") String productDesc,
								@RequestParam("productKeywords") String productKeywords,
								@RequestParam("productPrice") double productPrice,
								@RequestParam("productImage") MultipartFile productImage, Model m) 
	{
		String path = imgUpload.saveImage(productImage);
		
		Product product = new Product();
		product.setCatId(catId);
		product.setBrandId(brandId);
		product.setProductDesc(productDesc);
		product.setProductId(productId);
		product.setProductImage(path);
		product.setProductKeywords(productKeywords);
		product.setProductPrice(productPrice);
		product.setProductTitle(productTitle);
		
		int save = adminServices.addNewProduct(product);
		if(save > 0) {
			m.addAttribute("smsg", "Product Added Sucessfully :)");
			return "admin_add_product";
		}	
		m.addAttribute("emsg", "Error in adding product :(");
		return "admin_add_product";
	}
	
	
	@RequestMapping("/viewFeedback")
	public String viewFeedback(HttpSession session, Model m)
	{
		if(session.getAttribute("admin") != null)
		{
			List<UserFeedback> allFeedbacks = adminServices.getAllFeedbacks();
			if(!allFeedbacks.isEmpty() && allFeedbacks != null) {
				m.addAttribute("feedbacks", allFeedbacks);
				return "view_feedback";
			}else {
				return "feedbacks_notfound";
			}
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@RequestMapping("/manageUsers")
	public String manageUsers(HttpSession session, Model m)
	{
		if(session.getAttribute("admin") != null)
		{
			List<User> allUsers = adminServices.viewAllUsers();
			if(!allUsers.isEmpty()) {
				m.addAttribute("users",allUsers );
				return "Manage user";
			}
			return "users not found";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@RequestMapping("/lgout")
	public String logOut(HttpSession session)
	{
		session.invalidate();
		return "admin_login";
	}
	
	@RequestMapping("/removeuser")
	public String removeUser(@RequestParam("id") String userName, HttpSession session) {
		adminServices.removeUser(userName);
		session.setAttribute("rmsg", "Product Removed Sucessfully");
		return "redirect:manageUsers";
	}
	
	@RequestMapping("/viewproducts")
	public String manageProducts(HttpSession session, Model m)
	{
		if(session.getAttribute("admin") != null)
		{
			List<Product> allProducts = adminServices.viewAllProducts();
			if(!allProducts.isEmpty()) {
				m.addAttribute("products",allProducts );
				return "manage product";
			}
			return "admin_prod_not_found";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
	
	@RequestMapping("/removeproduct")
	public String removeProduct(@RequestParam("id") int productId, HttpSession session) {
		adminServices.removeProduct(productId);
		session.setAttribute("rmsg", "Product Removed Sucessfully");
		return "redirect:viewproducts";
	}
	
	@RequestMapping("/manageOrder")
	public String manageOrders(HttpSession session ,Model m)
	{		
		if(session.getAttribute("admin") != null)
		{
			List<Orders> viewAllOrders = adminServices.viewAllOrders();
			if(!viewAllOrders.isEmpty()) {
				m.addAttribute("orders",viewAllOrders );
				return "admin_manage_orders";
			}
			return "orders_not_found";
		}else {
			session.setAttribute("sesMsg", "Please Login First :(");
			return "admin_login";
		}
	}
}
