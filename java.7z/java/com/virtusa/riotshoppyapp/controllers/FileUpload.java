package com.virtusa.riotshoppyapp.controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUpload
{
	@Autowired
	ServletContext context; 
	private static final Logger logger = LoggerFactory
			.getLogger(FileUpload.class);
	
	public  String saveImage(MultipartFile file)
	{
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				String path =  context.getRealPath("");
				path = path.replace("\\", "/");
				String[] split = path.split("/");
				String p ="";
				for(String s : split)
				{
					if(s.equalsIgnoreCase(".metadata"))
						break;
					p += s+"/";
				}
				String rootPath = p+ "riotshoppy/src/main/webapp";
				System.out.println("Current relative path is: " + rootPath);
				
				System.out.println(rootPath);
				File dir = new File(rootPath + File.separator + "resources/photos");
				
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir
						+ File.separator + file.getOriginalFilename());
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				
				logger.info("Server File Location="
						+ serverFile.getAbsolutePath());

				return "photos/" + file.getOriginalFilename();
			} catch (Exception e) {
				return null;
			}
		}else {
			return "photos/user.png";
		}
	}
	
	
}
