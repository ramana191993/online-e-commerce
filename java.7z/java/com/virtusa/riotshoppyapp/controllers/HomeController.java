package com.virtusa.riotshoppyapp.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.virtusa.riotshoppyapp.dto.UserFeedback;
import com.virtusa.riotshoppyapp.servicesimpl.UserServicesImpl;

@Controller
public class HomeController 
{
	@Autowired
	private UserServicesImpl userServices;
	
	@RequestMapping("/home")
	public String getHomePage()
	{
		return "index";
	}
	
	@RequestMapping("/about")
	public String getAboutPage()
	{
		return "about";
	}
	
	@RequestMapping("/contact")
	public String getContactPage(@ModelAttribute("feedback") UserFeedback feedBack)
	{
		return "contact";
	}
	
	@PostMapping("/feedback")
	public String saveFeedback(Model msg ,@Valid @ModelAttribute("feedback") UserFeedback feedBack, Errors err)
	{
		if(err.hasErrors()) 
		{
			return "contact";
		}else 
		{
			int save = userServices.saveFeedback(feedBack);
			if(save > 0) {
				msg.addAttribute("msg", "Thank you for Your valuable Feedback :)");
				return "contact";
			}
			msg.addAttribute("msg", "Error in  Your Feedback :(");
			return "contact";
		}
	}

}
