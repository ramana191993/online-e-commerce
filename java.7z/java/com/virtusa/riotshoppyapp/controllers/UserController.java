package com.virtusa.riotshoppyapp.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;
import com.virtusa.riotshoppyapp.daoimpl.UserDaoImpl;
import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.Rating;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.servicesimpl.UserServicesImpl;

@Controller
public class UserController
{
	
	@Autowired
	private FileUpload fileUpload;

	@Autowired
	UserServicesImpl userServices;
	
	@RequestMapping("/lg")
	public String getLoginPage(@ModelAttribute("u") User user,Model m)
	{
		return "user_login";
	}
		
	@RequestMapping("/login")
	public String loginValidation(@Valid @ModelAttribute("u") User user, Errors error, HttpSession session, Model m)
	{
		User u = userServices.loginValidation(user);
		if(u != null)
		{
			session.setAttribute("user", u);
			List<Cart> cartItems = userServices.viewAllCartProducts(user);
			if( cartItems != null)
				session.setAttribute("cart", cartItems);
			return "user_index";
		}
		m.addAttribute("msg", "Username and password are not match try again :(");
		return "user_login";
	}
	
	@RequestMapping("/ureg")
	public String getUserRegistrationPage()
	{
		return "user_registration";
	}
	
	@RequestMapping(value = "/register" , method = RequestMethod.POST)
	public String registerUser(@RequestParam("firstName") String firstName,
							   @RequestParam("lastName") String lastName,
							   @RequestParam("phoneNumber") long phoneNumber,
							   @RequestParam("userName") String userName,
							   @RequestParam("password") String password,
							   @RequestParam("securityQuestion") int securityQuestion,
							   @RequestParam("securityAnswer") String securityAnswer,
							   @RequestParam("address1") String address1,
							   @RequestParam("address2") String address2,
							   @RequestParam("userImage") MultipartFile userImage, Model m)
	{
			
			String saveImage = fileUpload.saveImage(userImage);
			
			User userObj = new User();			
			userObj.setFirstName(firstName);
			userObj.setLastName(lastName);
			userObj.setPhoneNumber(phoneNumber);
			userObj.setUserName(userName);
			userObj.setPassword(password);
			userObj.setSecurityQuestion(securityQuestion);
			userObj.setSecurityAnswer(securityAnswer);
			userObj.setAddress1(address1);
			userObj.setAddress2(address2);
			userObj.setUserImage(saveImage);
						
			int reg = userServices.userRegistration(userObj);
			
			if(reg == 2)
			{
				m.addAttribute("msg", "You already registered Please Login :)");
				return "user_registration";
				
			}else if( reg > 0) {
				m.addAttribute("msg", "Registered Sucessfully :)");
				return "user_registration";
			}
			else
			{
				m.addAttribute("msg", "Error Please Try again :(");
				return "user_registration";
			}
	}
	
	@RequestMapping("/forgtpass")
	public String getForgotPasswordPage(@Valid @ModelAttribute("u") User user, Errors error)
	{
		return "forgot_password";
	}
	
	@PostMapping("/fpassword")
	public String validateForgotCredentials(@ModelAttribute("u") User user, Model m, Errors error)
	{
		boolean validate = userServices.validateForgotCredentials(user);
		if(validate)
		{
			m.addAttribute("msg", "Now You can reset your password :)");
			m.addAttribute("userName", user.getUserName());
			return "change_password";
		}else
		{	
			m.addAttribute("msg", "Your details are not valid please try again :(");
			return "forgot_password";
		}
	}
	
	@PostMapping("/resetpassword")
	public String resetPassword(@ModelAttribute("u") User user, Model m)
	{
		int update = userServices.resetPassword(user);
		if(update > 0)
		{
			m.addAttribute("msg", "Password Resetted Sucessfully :)");
			return "user_login";
		}
		m.addAttribute("msg", "Error Please try again :(");
		return "change_password";
	}
	
	@RequestMapping("/uhome")
	public String getUserHomePage(HttpSession session)
	{
		if(session.getAttribute("user") != null) {
			return "user_index";
		}
		else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/user_products")	
	public String displayProducts(Model m,HttpSession session)
	{
		User user = (User)session.getAttribute("user");
		if(user != null) {
			List<Product> products = userServices.viewAllProducts();
			List<Cart> cartItems = userServices.viewAllCartProducts(user);
			
				if(products != null) 
				{
					m.addAttribute("products", products);
					if( cartItems != null)
						session.setAttribute("cart", cartItems);
					return "all_products";
				}
				return "product_not_found";
		}
		session.setAttribute("sesmsg", "Please Login First");
		return "redirect:lg";
	}
	
	@PostMapping("/addprodtocart")
	public String addProductToCart(@ModelAttribute Cart cart)
	{
		int a = userServices.addProductToCart(cart);
		return "redirect:user_products";
	}
	
	@RequestMapping("/viewcart")
	public String viewCartItems(HttpSession session)
	{
		User user = (User)session.getAttribute("user");
		if(user != null)
		{
			List<Cart> cartItems = userServices.viewAllCartProducts(user);
			if( cartItems != null)
				session.setAttribute("cart", cartItems);
			return "view_cart";
		}
		session.setAttribute("sesmsg", "Please Login First");
		return "redirect:lg";
	}
	
	@RequestMapping("/changepass")
	public String getChangePasswordPage(HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{
			return "update_password";
		}else{
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@PostMapping("/updatePass")
	public String updatePassword(@RequestParam("userName") String userName,
								 @RequestParam("password") String password,
								 @RequestParam("npassword") String newPassword, Model m)
	{
		int up = userServices.updatePassword(userName, password, newPassword);
		System.out.println(up);
		if(up > 0) {
			m.addAttribute("umsg", "Password Updated Sucessfully :)");
		}else {
			m.addAttribute("umsg", "Entered Current password is not valid :(");
		}		
		return "update_password";
	}
	
	
	@PostMapping("/pricesort")
	public String sortProductsByPrice(@RequestParam("low") double lowPrice, @RequestParam("high") double maxPrice,Model m,HttpSession session)
	{
		if(session.getAttribute("user") != null)
		{
			List<Product> list = userServices.sortProductByPrice(lowPrice, maxPrice);
			if(list != null && !list.isEmpty())
			{
				m.addAttribute("priceProduct", list);
				return "filter_products_by_price";
			}
			return "product_not_found";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}
	
	@RequestMapping("/productsbycat")
	public String viewProductsByCategory(@RequestParam("id") int categoryId, Model m, HttpSession session) 
	{
		if(session.getAttribute("user") != null)
		{
			List<Product> prod = userServices.viewProductsByCategory(categoryId);
			List<Brands> viewAllBrands = userServices.viewAllBrands(categoryId);
			if(prod != null && !prod.isEmpty())
			{
				m.addAttribute("priceProduct", prod);
				session.setAttribute("allBrands", viewAllBrands);
				m.addAttribute("", viewAllBrands);
				return "category_wise_products";
			}
			return "product_not_found";
		}else {
			session.setAttribute("sesmsg", "Please Login First");
			return "redirect:lg";
		}
	}	
	
	@PostMapping("/productRating")
	public String saveProductRating(@RequestParam("rating") int rating,
									@RequestParam("productId") int productId,
									@RequestParam("brandId") int brandId) 
	{
		Rating r = new Rating();
		r.setProductId(productId);
		r.setRating(rating);
		r.setBrandId(brandId);
		
		userServices.saveUserProductRating(r);
		return "redirect:user_products";
	}	
	
	@RequestMapping("/lgout")
	public String logout(HttpSession session)
	{
		session.removeAttribute("user");
		session.invalidate();
		return "redirect:lg";
	}

}
