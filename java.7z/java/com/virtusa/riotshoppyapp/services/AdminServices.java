package com.virtusa.riotshoppyapp.services;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.dto.UserFeedback;

public interface AdminServices 
{
	//login Validation
	boolean loginValidation(String userName, String password);
	
	//Add New Brand
	int addNewBrand(Brands brand);
	
	//Get Brands 
	List<Brands> getBrandsList(int categoryId);
	
	//Add new Product 
	int addNewProduct(Product product);
	
	//Get All User Feedbacks
	List<UserFeedback> getAllFeedbacks();
	
	//get all users 
	List<User> viewAllUsers();
	
	//Remove User
	void removeUser(String userName);
	
	//View All Products
	List<Product> viewAllProducts();
	
	//Remove Product
	void removeProduct(int productId);
	
	//Get All Orders information
	List<Orders> viewAllOrders();
}
