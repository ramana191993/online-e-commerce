package com.virtusa.riotshoppyapp.services;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.ShippingAddress;
public interface UserCartServices
{
	//Decrease Cart product Quantity 
	void decreasePoductQty(Cart cart);
	
	//Increase Cart Product Quantity
	int increaseProductQty(Cart cart);
	
	//Checkout Page
	List<ShippingAddress> getAllShippingAddresses(String userName);
	
	//Add new Shipment Address
	int addNewShipmentAddress(ShippingAddress shipAddress);
	
	//Save Order
	int saveOrderInfo(String address,List<Cart> cart);
	
	//View Order
	List<Orders> viewOrder(int orderId);
	
	//Get All user Orders
	List<Orders> getAllOrder(String userName);
	
	//Cancel Order
	void cancelOrder(String orderId);
	
	//Filter products based on brand
	List<Product> getProductsByBrand(int brandId);
	
	// Get Single product
	Product getProduct(int productId);
}
