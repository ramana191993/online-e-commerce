package com.virtusa.riotshoppyapp.services;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.Rating;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.dto.UserFeedback;

public interface UserServices 
{
	
	//User Login Validation
	User loginValidation(User user);
	
	//User Registration
	int userRegistration(User user);
	
	//view All Products
	List<Product> viewAllProducts();
	
	//View Brands List
	List<Brands> viewAllBrands(int categoryId);
	
	//user forgot password validation
	boolean validateForgotCredentials(User user);
	
	//reset Forgot user password
	int resetPassword(User user);
	
	//Update User Password
	int updatePassword(String userName,String password,String newPassword);
	
	//Add product into Cart
	int addProductToCart(Cart cart);
	
	//View All Cart Items
	List<Cart> viewAllCartProducts(User user);
	
	//Search products based on price 
	List<Product> sortProductByPrice(double lowPrice, double maxPrice);
	
	//Display products based on Category
	List<Product> viewProductsByCategory(int categoryId);
	
	//Give Feedback
	int saveFeedback(UserFeedback feedBack);
	
	//Give Rating for Feedback
	int saveUserProductRating(Rating rating);
	
	//
	List<Rating> getProductRatings(int productId);
	
	//Caliculate Ratings 
	double getCaliculatedRating(int productId);
}