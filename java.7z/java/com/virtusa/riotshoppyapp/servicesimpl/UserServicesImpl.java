package com.virtusa.riotshoppyapp.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.riotshoppyapp.dao.BrandDao;
import com.virtusa.riotshoppyapp.daoimpl.CartDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.FeedbackDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.ProductDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.RatingDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.UserDaoImpl;
import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.Rating;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.dto.UserFeedback;
import com.virtusa.riotshoppyapp.services.UserServices;

@Service
public class UserServicesImpl implements UserServices
{
	@Autowired
	private UserDaoImpl userDao;
	
	@Autowired 
	private ProductDaoImpl product;
	
	@Autowired 
	private CartDaoImpl cartDao;
	
	@Autowired
	private BrandDao brandDao;
	
	@Autowired
	private FeedbackDaoImpl feedbackDao;
	
	@Autowired
	private RatingDaoImpl ratingDao;
	
	@Override
	public User loginValidation(User user)
	{
		 User u = userDao.getUserInformation(user.getUserName());
		 if(u != null) {
			 if(user.getUserName().equals(u.getUserName()) && u.getPassword().equals(user.getPassword()))
				 return u;
			 return null;
		 }else {
			 return null;
		 } 
		
	}

	@Override
	public int userRegistration(User user)
	{
		
		return userDao.register(user);
	}

	@Override
	public List<Product> viewAllProducts() {
		
		return product.viewAllProducts();
	}

	@Override
	public boolean validateForgotCredentials(User user) 
	{
		 User u = userDao.getUserInformation(user.getUserName());
		 System.out.println(user.getUserName());
		 if(u != null)
			 if(u.getUserName().equals(user.getUserName()) &&
						u.getSecurityQuestion() == user.getSecurityQuestion() && 
						  u.getSecurityAnswer().equals(user.getSecurityAnswer()))
					 return true;
		
		 return false;
	}

	@Override
	public int updatePassword(String userName,String password,String newPassword)
	{
		 User u = userDao.getUserInformation(userName);
		 if(u != null)
		 {
			 if(u.getPassword().equals(password)) 
			 {
				 u.setPassword(newPassword);
				 return userDao.updatePassword(u);
			 }

		 }
		 
		 return 0;
	}
	
	@Override
	public int resetPassword(User user)
	{
		
		return userDao.updatePassword(user);
	}
	
	@Override
	public int addProductToCart(Cart cart) 
	{
		return cartDao.addProductToCart(cart);
	}

	@Override
	public List<Cart> viewAllCartProducts(User user) {
		
		return cartDao.viewCartItems(user.getUserName());
	}

	
	@Override
	public List<Product> sortProductByPrice(double lowPrice, double maxPrice) 
	{
		return product.getProductsByPrice(lowPrice, maxPrice);
	}

	@Override
	public List<Product> viewProductsByCategory(int categoryId) 
	{
	 	return product.viewProductsByCategory(categoryId);
	}

	@Override
	public List<Brands> viewAllBrands(int categoryId)
	{		
		return brandDao.getBrandsList(categoryId);
	}

	@Override
	public int saveFeedback(UserFeedback feedBack) 
	{
		return feedbackDao.saveUserFeedback(feedBack);
	}

	@Override
	public int saveUserProductRating(Rating rating)
	{
		return ratingDao.saveProductRating(rating);
	}

	@Override
	public List<Rating> getProductRatings(int productId)
	{
		return ratingDao.getProductratings(productId);
	}

	@Override
	public double getCaliculatedRating(int productId) 
	{
		int r1,r2,r3,r4,r5; double d = 0.0;
		r1 = r2 = r3 = r4 = r5= 0;
		List<Rating> rating = ratingDao.getProductratings(productId);
		if(!rating.isEmpty()) {
			for(Rating r: rating) {
				int a = r.getRating();
				if(a == 5)
					r5 += 1;
				else if(a == 4)
					r4 += 1;
				else if(a == 3)
					r3 += 1;
				else if(a == 2)
					r2 += 1;
				else 
					r1 += 1;
			}
			
			int sum =( (r5 * 5) + (r4 * 4) + (r3 * 3) + (r2 * 2) + (r1 * 1) );
			int rsum = r1 + r2 + r3 + r4 + r5;
			d = ((sum / rsum) * 100);
			d = d/100;
		}
		return Math.round(d);
	}

	

}
