package com.virtusa.riotshoppyapp.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.riotshoppyapp.dao.FeedbackDao;
import com.virtusa.riotshoppyapp.daoimpl.BrandDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.OrderDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.ProductDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.UserDaoImpl;
import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.User;
import com.virtusa.riotshoppyapp.dto.UserFeedback;
import com.virtusa.riotshoppyapp.services.AdminServices;

@Service
public class AdminServicesImpl implements AdminServices
{
	@Autowired
	private BrandDaoImpl brandDao;
	
	@Autowired
	private ProductDaoImpl productDao;
	
	@Autowired
	private FeedbackDao feedbackDao;
	
	@Autowired
	private UserDaoImpl userDao;
	
	@Autowired
	OrderDaoImpl orderDao;
	
	@Override
	public boolean loginValidation(String userName, String password)
	{
		if(userName.equals("admin") && password.equals("riot"))
			return true;
		return false;
	}

	@Override
	public int addNewBrand(Brands brand)
	{
		return brandDao.addNewBrand(brand);
	}

	@Override
	public List<Brands> getBrandsList(int categoryId)
	{		
		return brandDao.getBrandsList(categoryId);
	}

	@Override
	public int addNewProduct(Product product) 
	{
		return productDao.addProduct(product);
	}

	@Override
	public List<UserFeedback> getAllFeedbacks()
	{
		return feedbackDao.viewAllFeedbacks();
	}

	@Override
	public List<User> viewAllUsers() 
	{		
		return userDao.viewAllUsers();
	}

	@Override
	public void removeUser(String userName) {
		userDao.removeUser(userName);
	}

	@Override
	public List<Product> viewAllProducts() {
		
		return productDao.viewAllProducts();
	}

	@Override
	public void removeProduct(int productId) {
		productDao.removeProduct(productId);
	}

	@Override
	public List<Orders> viewAllOrders() {
		return orderDao.viewAllOrders();
	}

}
