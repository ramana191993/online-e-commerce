package com.virtusa.riotshoppyapp.servicesimpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.riotshoppyapp.daoimpl.CartDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.OrderDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.ProductDaoImpl;
import com.virtusa.riotshoppyapp.daoimpl.ShippingAddressDaoImpl;
import com.virtusa.riotshoppyapp.dto.Brands;
import com.virtusa.riotshoppyapp.dto.Cart;
import com.virtusa.riotshoppyapp.dto.Orders;
import com.virtusa.riotshoppyapp.dto.Product;
import com.virtusa.riotshoppyapp.dto.ShippingAddress;
import com.virtusa.riotshoppyapp.services.UserCartServices;

@Service
public class UserCartServicesImpl implements UserCartServices
{
	@Autowired
	private CartDaoImpl cartDao;
	
	@Autowired
	private ShippingAddressDaoImpl address;
	
	@Autowired
	private OrderDaoImpl orderDao;
	
	@Autowired
	private ProductDaoImpl productDao;
	
	@Override
	public void decreasePoductQty(Cart cart)
	{
		cartDao.removeProductFromCart(cart);
	}

	@Override
	public int increaseProductQty(Cart cart)
	{
		return cartDao.increaseProductQty(cart);
	}

	@Override
	public List<ShippingAddress> getAllShippingAddresses(String userName)
	{
		return address.getAllShippingAddress(userName);
	}

	@Override
	public int addNewShipmentAddress(ShippingAddress shipAddress) 
	{
		return 	address.addShippingAddress(shipAddress);
	}

	@Override
	public int saveOrderInfo(String address, List<Cart> cart)
	{
		Random r = new Random();		
		int transactionId = r.nextInt(99999999);
		int orderId = r.nextInt(999999999);
		Date date = new Date();
		String strDateFormat = "hh:mm:ss a";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		String currentDate= dateFormat. format(date);
		List<Orders> order = new LinkedList<>();
		int a = 0;
		
		for(Cart c : cart)
		{
			String userName = c.getUserName();
			int productId = c.getProductId();
			String productImage = c.getProdImage();
			int orderQty = c.getProdQty();
			double price = c.getProdPrice();
			String status = "orderPlaced";
			
			order.add(new Orders(orderId, userName, productId, productImage, orderQty, price, address, currentDate, transactionId, status));
		}
		
		int res = orderDao.saveOrder(order);
		if( res > 0)
		{	for(Cart c : cart)
			cartDao.removeProductFromCart(c);
			return orderId;
		}else {
			return 0;
		}
	}

	@Override
	public List<Orders> viewOrder(int orderId)
	{
		return orderDao.viewOrder(orderId);
	}

	@Override
	public List<Orders> getAllOrder(String userName)
	{
		return orderDao.viewAllOrders(userName);
	}

	@Override
	public void cancelOrder(String id)
	{
		String[] split = id.split(" ");
		int orderNo = Integer.parseInt(split[0]);
		int orderId = Integer.parseInt(split[1]);
		System.out.println(orderId + "  " + orderId);
		orderDao.cancelOrder(orderNo, orderId);
	}

	@Override
	public List<Product> getProductsByBrand(int brandId)
	{
		return productDao.getProductBasBrand(brandId);
	}

	@Override
	public Product getProduct(int productId) 
	{
		return productDao.getProduct(productId);
	}
	
	
}
