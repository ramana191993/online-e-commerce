package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.ShippingAddress;

public interface ShippingAddressDao 
{
	//Add new shhiping Address
	int addShippingAddress(ShippingAddress address);
	
	//get All user Shipping Addresses
	List<ShippingAddress> getAllShippingAddress(String userName);
}
