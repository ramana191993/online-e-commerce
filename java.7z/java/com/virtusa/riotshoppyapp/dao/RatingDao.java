package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Rating;

public interface RatingDao 
{
	//add Rating
	int saveProductRating(Rating rating);
	
	//Get Ratings 
	List<Rating> getProductratings(int productId);
	
	// Get Single Product Rating
	Rating getRatingInfo(int ratingId);
}
