package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.UserFeedback;

public interface FeedbackDao 
{
	//Save User Feedbacks
	int saveUserFeedback(UserFeedback feedback);
	
	// View All user Feedback
	List<UserFeedback> viewAllFeedbacks();
	
}
