package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Product;

public interface ProductDao 
{
	//Add new Product
	int addProduct(Product product);
	
	//Get Single Product
	Product getProduct(int productId);
	
	//Get All Products
	List<Product> viewAllProducts();
	
	//Filter Products based on price
	List<Product> getProductsByPrice(double lowPrice, double maxPrice);
	
	//Remove product
	void removeProduct(int productId);
	
	//View Products based on category
	List<Product> viewProductsByCategory(int categoryId);
	
	//View Products based on brand
	List<Product> getProductBasBrand(int brandId);
	
	//Update Product
	int updateProduct(Product product);
	
	

}
