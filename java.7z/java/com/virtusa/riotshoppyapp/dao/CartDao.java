package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Cart;

public interface CartDao
{
	//add product into cart
	int addProductToCart(Cart cart);
	
	//view All Cart items of Single user
	List<Cart> viewCartItems(String userName);
	
	//Remove Product From Cart
	void removeProductFromCart(Cart cart);
	
	//increase Product Quantity in Cart
	int increaseProductQty(Cart cart);
	
	
}
