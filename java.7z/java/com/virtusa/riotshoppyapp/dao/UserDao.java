package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.User;

public interface UserDao 
{
	//User Registration
	int register(User user);
	
	// Get Single user Information
	User getUserInformation(String userName);
	
	//Update new Password
	int updatePassword(User user);
	
	//Get All the user Information
	List<User> viewAllUsers();
	
	//Remove user
	void removeUser(String userName);
	
	//Update user profile
	int updateUserProfile(User user);	
	
}
