package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Brands;

public interface BrandDao 
{
	//Add New Brand
	int addNewBrand(Brands brand);
	
	//Get Brands List
	List<Brands> getBrandsList(int categoryId);
}
