package com.virtusa.riotshoppyapp.dao;

import java.util.List;

import com.virtusa.riotshoppyapp.dto.Orders;


public interface OrderDao 
{
	//Place User Order
	int saveOrder(List<Orders> order);
	
	//Get Single User Orders 
	List<Orders> viewOrder(int orderId);
	
	//Get All user Orders
	List<Orders> viewAllOrders(String userName);
	
	//Cancel Order
	void cancelOrder(int orderNo, int orderId);
	
	//Get All Orders Information
	List<Orders> viewAllOrders();
}
