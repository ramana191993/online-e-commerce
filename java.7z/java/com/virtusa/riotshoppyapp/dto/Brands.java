package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="brands")
public class Brands implements Serializable
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "brand_id")
	private int brandID;
	@Column(name = "brand_name")
	private String brandName;
	@Column(name = "cat_id")
	private int categoryId;
	
	public Brands() 
	{
		
	}

	public int getBrandID() 
	{
		return brandID;
	}

	public void setBrandID(int brandID)
	{
		this.brandID = brandID;
	}

	public String getBrandName()
	{
		return brandName;
	}

	public void setBrandName(String brandName) 
	{
		this.brandName = brandName;
	}

	public int getCategoryId() 
	{
		return categoryId;
	}

	public void setCategoryId(int categoryId)
	{
		this.categoryId = categoryId;
	}

	@Override
	public String toString() {
		return "Brands [brandID=" + brandID + ", brandName=" + brandName + ", categoryId=" + categoryId + "]";
	}
	
}
