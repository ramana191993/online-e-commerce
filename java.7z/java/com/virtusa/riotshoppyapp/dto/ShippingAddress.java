package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shipping_table")
public class ShippingAddress implements Serializable
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "address_id")
	private int addressId;
	@Column(name = "user_email")
	private String userName;
	@Column(name = "user_name")
	private String fullName;
	@Column(name = "user_phno")
	private long phoneNumber;
	@Column(name = "pin_code")
	private int pinCode;
	@Column(name = "house_info")
	private String houseInfo;
	@Column(name = "street_info")
	private String streetInfo;
	@Column(name = "land_mark")
	private String landMark;
	@Column(name = "tow_or_city")
	private String townOrCity;
	@Column(name = "state")
	private String state;
	@Column(name = "address_type")
	private String addressType;
	
	public ShippingAddress() {
		// TODO Auto-generated constructor stub
	}
	
	public ShippingAddress(int addressId, String userName, long phoneNumber, int pinCode, String houseInfo,
			String streetInfo, String landMark, String townOrCity, String state, String addressType) {
		this.addressId = addressId;
		this.fullName = userName;
		this.phoneNumber = phoneNumber;
		this.pinCode = pinCode;
		this.houseInfo = houseInfo;
		this.streetInfo = streetInfo;
		this.landMark = landMark;
		this.townOrCity = townOrCity;
		this.state = state;
		this.addressType = addressType;
	}

	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getHouseInfo() {
		return houseInfo;
	}

	public void setHouseInfo(String houseInfo) {
		this.houseInfo = houseInfo;
	}

	public String getStreetInfo() {
		return streetInfo;
	}

	public void setStreetInfo(String streetInfo) {
		this.streetInfo = streetInfo;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public String getTownOrCity() {
		return townOrCity;
	}

	public void setTownOrCity(String townOrCity) {
		this.townOrCity = townOrCity;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	@Override
	public String toString() {
		return  addressId + "," + fullName + "," + phoneNumber + ", pinCode=" + pinCode + "," + houseInfo + "," + streetInfo + ","
				+ landMark + "," + townOrCity + "," + state + "," + addressType ;
	}
	
	
}
