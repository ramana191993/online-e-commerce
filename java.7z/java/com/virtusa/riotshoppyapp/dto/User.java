package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import org.hibernate.validator.constraints.Length;

@Entity
@Table( name = "user_info")
public class User implements Serializable
{
	private static final long serialVersionUID = 1;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "user_id")
	private int userId;
	@Column(name = "first_name", nullable = true)
	@NotEmpty(message = "First Name Cannot be Empty")
	private String firstName;
	@Column(name = "last_name", nullable = true)
	@NotEmpty(message = "Last Name Cannot be Empty")
	private String lastName;
	@Column(name = "user_name", nullable = true, unique = true)
	@NotEmpty(message = "User Name Cannot be Empty")
	private String userName; 
	@Column(name = "password", nullable = true)
	@NotEmpty(message = "Password Cannot be Empty")
	@Length(min = 8, max = 25, message = "Password Must Contain 8 - 25 Digits")
	private String password;
	@Column(name = "phone_number", nullable = true)
	private long phoneNumber;
	@NotEmpty(message = "Please Enter the Address")
	@Column(name = "address1")
	private String address1;
	@Column(name = "address2")
	private String address2;
	@Column(name = "user_image")
	private String userImage;
	@Column(name = "security_question")
	private int securityQuestion;
	@Column(name = "security_answer")
	@NotEmpty(message = "Security Answer Cannot be Empty")
	private String securityAnswer;
	
	//Default Constructor
	public User() 
	{
		System.out.println(getClass().getSimpleName() + " Object is created");
	}
	
	/**
	 * 
	 * @param userId
	 * @param firstName
	 * @param lastName
	 * @param userName
	 * @param password
	 * @param phoneNumber
	 * @param address1
	 * @param address2
	 * @param userImage
	 * @param securityQuestion
	 * @param securityAnswer
	 */
	public User(int userId, String firstName, String lastName, String userName, String password, long phoneNumber,
			String address1, String address2, String userImage, int securityQuestion, String securityAnswer) {
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.phoneNumber = phoneNumber;
		this.address1 = address1;
		this.address2 = address2;
		this.userImage = userImage;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getUserImage() {
		return userImage;
	}

	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}

	public int getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(int securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", userName="
				+ userName + ", password=" + password + ", phoneNumber=" + phoneNumber + ", address1=" + address1
				+ ", address2=" + address2 + ", userImage=" + userImage + ", securityQuestion=" + securityQuestion
				+ ", securityAnswer=" + securityAnswer + "]";
	}
	
}
