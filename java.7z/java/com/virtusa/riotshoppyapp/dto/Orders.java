package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="orders")
public class Orders implements Serializable
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int sNo;
	@Column( name = "order_id")
	private int orderId;
	@Column( name = "user_id")
	private String userName;
	@Column( name = "product_id")
	private int productId;
	@Column( name = "product_image")
	private String productImage;
	@Column( name = "product_qty")
	private int orderQty;
	@Column( name = "total_price")
	private double totalPrice;
	@Column( name = "shipping_address")
	private String Address;
	@Column(name = "order_date")
	private String orderDate;
	@Column( name = "trx_id")
	private int transactionId;
	@Column( name = "p_status")
	private String productStatus;
	
	public Orders() {
		// TODO Auto-generated constructor stub
	}

	
	public Orders(int orderId, String userName, int productId, String productImage, int orderQty, double totalPrice,
			String address, String orderDate, int transactionId, String productStatus) {
		this.orderId = orderId;
		this.userName = userName;
		this.productId = productId;
		this.productImage = productImage;
		this.orderQty = orderQty;
		this.totalPrice = totalPrice;
		Address = address;
		this.orderDate = orderDate;
		this.transactionId = transactionId;
		this.productStatus = productStatus;
	}

	

	public int getsNo() {
		return sNo;
	}


	public void setsNo(int sNo) {
		this.sNo = sNo;
	}


	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", userName=" + userName + ", productId=" + productId + ", productImage="
				+ productImage + ", orderQty=" + orderQty + ", totalPrice=" + totalPrice + ", Address=" + Address
				+ ", orderDate=" + orderDate + ", transactionId=" + transactionId + ", productStatus=" + productStatus
				+ "]";
	}	
	
}
