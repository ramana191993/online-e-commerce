/**
 * 
 */
package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ramanaiahpd
 *
 */
@Entity
@Table(name = "products")
public class Product implements Serializable
{
	  @Id
	  @Column(name = "product_id")
	  private int productId;
	  @Column(name = "product_cat")
	  private int catId;
	  @Column(name = "product_brand")
	  private int brandId;
	  @Column(name = "product_title")
	  private String productTitle;
	  @Column(name = "product_price")
	  private double productPrice;
	  @Column(name = "product_desc")
	  private String productDesc;
	  @Column(name = "product_image")
	  private String productImage;
	  @Column(name = "product_keywords")
	  private String productKeywords;
	  
	  public Product() {
		// TODO Auto-generated constructor stub
	  }

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public String getProductKeywords() {
		return productKeywords;
	}

	public void setProductKeywords(String productKeywords) {
		this.productKeywords = productKeywords;
	}

}
