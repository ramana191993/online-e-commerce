package com.virtusa.riotshoppyapp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "user_feedback")
public class UserFeedback implements Serializable
{
	
	private static final long serialVersionUID = -2256972481836948263L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "feedback_id")
	private int id;
	@NotEmpty(message = "User Name Cannot be Empty")
	@Column(name = "feedback_username")
	private String userName;
	@NotEmpty(message = "email Should not be empty")
	@Email
	@Column(name = "user_email")
	private String userEmail;
	@Column(name = "user_phno")
	@NotEmpty(message = " Phone Number should not be empty")
	@Length(max = 10 ,min = 10, message = "Phone Number should be 10 Digits Only")
	private String phoneNumber;
	@Column(name = "feedack_msg")
	@NotEmpty(message = "Message should not be empty")
	private String feedbackMessage;
	
	public UserFeedback()
	{
		System.out.println(getClass().getSimpleName() + " object is created");
	}

	public UserFeedback(int id, String userName, String userEmail, String phoneNumber, String feedbackMessage) 
	{
		this.id = id;
		this.userName = userName;
		this.userEmail = userEmail;
		this.phoneNumber = phoneNumber;
		this.feedbackMessage = feedbackMessage;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getUserEmail()
	{
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getPhoneNumber()
	{
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}

	public String getFeedbackMessage()
	{
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) 
	{
		this.feedbackMessage = feedbackMessage;
	}

	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}

	@Override
	public String toString()
	{
		return "UserFeedback [id=" + id + ", userName=" + userName + ", userEmail=" + userEmail + ", phoneNumber="
				+ phoneNumber + ", feedbackMessage=" + feedbackMessage + "]";
	}
}
